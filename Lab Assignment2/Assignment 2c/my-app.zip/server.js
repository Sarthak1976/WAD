const express = require('express');
const path = require('path');

const app = express();


app.use(express.static(path.join(__dirname, 'dist/my-app/browser')));


app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/my-app/browser/index.html'));
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});