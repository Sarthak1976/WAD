const User = require('../model/user');

// CREATE
exports.create = async (req, res) => {
  try {
    const user = new User(req.body);
    const saved = await user.save();
    res.json({ message: "User created", user: saved });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// READ ALL
exports.findAll = async (req, res) => {
  const users = await User.find();
  res.json(users);
};

// READ ONE
exports.findOne = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    res.json(user);
  } catch {
    res.status(404).json({ message: "User not found" });
  }
};

// UPDATE
exports.update = async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.params.id, req.body);
    res.json({ message: "User updated" });
  } catch {
    res.status(500).json({ message: "Update failed" });
  }
};

// DELETE
exports.destroy = async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: "User deleted" });
  } catch {
    res.status(500).json({ message: "Delete failed" });
  }
};